#include <iostream>
using namespace std;

char board[3][3] = { {'1','2','3'},
                     {'4','5','6'},
                     {'7','8','9'} };

void printBoard() {
    cout << "\n";
    for(int i=0; i<3; i++) {
        for(int j=0; j<3; j++) {
            cout << board[i][j] << " ";
        }
        cout << "\n";
    }
}

bool checkWinner(char player) {
    // cek baris
    for(int i=0; i<3; i++) {
        if(board[i][0]==player && board[i][1]==player && board[i][2]==player)
            return true;
    }
    // cek kolom
    for(int j=0; j<3; j++) {
        if(board[0][j]==player && board[1][j]==player && board[2][j]==player)
            return true;
    }
    // cek diagonal
    if(board[0][0]==player && board[1][1]==player && board[2][2]==player)
        return true;
    if(board[0][2]==player && board[1][1]==player && board[2][0]==player)
        return true;

    return false;
}

bool isFull() {
    for(int i=0; i<3; i++) {
        for(int j=0; j<3; j++) {
            if(board[i][j] != 'X' && board[i][j] != 'O')
                return false;
        }
    }
    return true;
}

int main() {
    char player = 'X';
    int choice;
    bool gameOver = false;

    while(!gameOver) {
        printBoard();
        cout << "Giliran pemain " << player << " pilih angka (1-9): ";
        cin >> choice;

        int row = (choice-1)/3;
        int col = (choice-1)%3;

        if(board[row][col] != 'X' && board[row][col] != 'O') {
            board[row][col] = player;

            if(checkWinner(player)) {
                printBoard();
                cout << "Pemain " << player << " menang!\n";
                gameOver = true;
            } else if(isFull()) {
                printBoard();
                cout << "Permainan seri!\n";
                gameOver = true;
            } else {
                player = (player=='X') ? 'O' : 'X';
            }
        } else {
            cout << "Posisi sudah terisi, coba lagi!\n";
        }
    }

    return 0;
}
