#include <iostream>
using namespace std;

int main(){
    int nilai;
    cout << "masukan nilai ujian";
    cin >> nilai;
    
    if (nilai >= 75){
        cout << "selamat, kamu lulus!" << endl;
    } else {
        cout << "maaf, kamu belum lulus:(" << endl;
    }
    
    return 0;
}