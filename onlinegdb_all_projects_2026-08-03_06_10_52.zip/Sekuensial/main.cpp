#include <iostream>
using namespace std;

int main(){
    double luas, panjang, lebar;
    cout << "masukan panjang";
    cin >> panjang;
    cout<<"masukan lebar";
    cin >> lebar;
    
    //menghitung luas persegi
    luas = panjang * lebar;
    
    cout << "Luas persegi panjang: " << luas << endl;
    
    return 0;
}