#include <iostream>
using namespace std;

int main() {
    int umur;
    
    cout << "Masukkan umur kamu: ";
    cin >> umur;
    
    //Percabangan IF sederhana
    if (umur >= 17) {
        cout << "Kamu sudah dewasa!" << endl;
    }
    
    return 0;
}